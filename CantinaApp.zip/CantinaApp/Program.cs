﻿/*
Heurísticas aplicadas:

#1 - Visibilidade do Status:
Mensagens como "[Passo 1 de 3]" indicam em qual etapa o usuário está.

#3 - Controle e Liberdade:
O usuário pode digitar "voltar" para retornar ao passo anterior
ou "cancelar" para encerrar o pedido a qualquer momento.

#9 - Ajuda e Tratamento de Erros:
Mensagens claras quando o usuário digita algo inválido,
como código fora do intervalo ou letras no lugar de números.
*/

using System;

class Program
{
    static void Main()
    {
        int passo = 1;
        int codigoProduto = 0;
        int quantidade = 0;

        while (true)
        {
            // PASSO 1 - Código do Produto
            while (passo == 1)
            {
                Console.WriteLine("[Passo 1 de 3] - Digite o código do produto (1 a 10):");
                string entrada = Console.ReadLine().ToLower();

                if (entrada == "cancelar")
                {
                    Console.WriteLine("Pedido cancelado.");
                    return;
                }

                if (int.TryParse(entrada, out codigoProduto))
                {
                    if (codigoProduto >= 1 && codigoProduto <= 10)
                    {
                        passo = 2;
                    }
                    else
                    {
                        Console.WriteLine($"Código {codigoProduto} não encontrado. Nossos códigos vão de 1 a 10. Tente novamente.");
                    }
                }
                else
                {
                    Console.WriteLine("Entrada inválida. Digite um número.");
                }
            }

            // PASSO 2 - Quantidade
            while (passo == 2)
            {
                Console.WriteLine("[Passo 2 de 3] - Digite a quantidade:");
                string entrada = Console.ReadLine().ToLower();

                if (entrada == "cancelar")
                {
                    Console.WriteLine("Pedido cancelado.");
                    return;
                }

                if (entrada == "voltar")
                {
                    passo = 1;
                    break;
                }

                if (int.TryParse(entrada, out quantidade) && quantidade > 0)
                {
                    passo = 3;
                }
                else
                {
                    Console.WriteLine("Quantidade inválida. Digite um número maior que zero.");
                }
            }

            // PASSO 3 - Confirmação
            while (passo == 3)
            {
                Console.WriteLine("[Passo 3 de 3] - Confirmar pedido:");
                Console.WriteLine($"Produto: {codigoProduto} | Quantidade: {quantidade}");
                Console.WriteLine("Digite 'confirmar', 'voltar' ou 'cancelar':");

                string entrada = Console.ReadLine().ToLower();

                if (entrada == "confirmar")
                {
                    Console.WriteLine("Pedido realizado com sucesso!");
                    return;
                }
                else if (entrada == "voltar")
                {
                    passo = 2;
                    break;
                }
                else if (entrada == "cancelar")
                {
                    Console.WriteLine("Pedido cancelado.");
                    return;
                }
                else
                {
                    Console.WriteLine("Opção inválida.");
                }
            }
        }
    }
}
